import { TableSkeleton } from "@/components/ui/skeletons";

export default function ClassLoading() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-teal-50 to-cyan-50">
      {/* Header skeleton */}
      <div className="w-full bg-[#dfdfdf] py-6 shadow-md">
        <div className="container max-w-[1152px] mx-auto flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-12 h-12 bg-gray-300 rounded-lg animate-pulse" />
            <div className="h-6 w-24 bg-gray-300 rounded animate-pulse" />
          </div>
          <div className="flex gap-4 items-center">
            <div className="h-8 w-16 bg-gray-300 rounded animate-pulse" />
            <div className="h-8 w-20 bg-gray-300 rounded animate-pulse" />
            <div className="h-10 w-24 bg-gray-300 rounded-lg animate-pulse" />
          </div>
        </div>
      </div>

      {/* Navbar skeleton */}
      <div className="w-full bg-[#302f2fd1] px-14 py-6">
        <div className="flex gap-8">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="h-8 w-24 bg-gray-600/30 rounded animate-pulse" />
          ))}
        </div>
      </div>

      {/* Content skeleton */}
      <div className="flex items-start justify-center p-6 pt-10">
        <div className="w-full max-w-7xl shadow-2xl border-0 rounded-xl overflow-hidden bg-white">
          {/* Card Header skeleton */}
          <div className="bg-gradient-to-r from-emerald-500 to-teal-600 rounded-t-xl px-8 py-5 flex justify-between items-center">
            <div>
              <div className="h-7 w-40 bg-white/20 rounded animate-pulse" />
              <div className="h-4 w-60 bg-white/10 rounded animate-pulse mt-2" />
            </div>
            <div className="h-10 w-36 bg-white/20 rounded-lg animate-pulse" />
          </div>
          {/* Search skeleton */}
          <div className="p-4 border-b border-gray-100 bg-white">
            <div className="h-10 w-80 bg-gray-100 rounded-lg animate-pulse" />
          </div>
          {/* Table skeleton */}
          <div className="p-0">
            <TableSkeleton rows={8} cols={5} />
          </div>
        </div>
      </div>
    </div>
  );
}
